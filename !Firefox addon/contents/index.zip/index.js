var tabs = require("sdk/tabs");
var { ToggleButton } = require('sdk/ui/button/toggle');
var panels = require("sdk/panel");
var self = require("sdk/self");
var pageMod = require("sdk/page-mod");

var ss = require("sdk/simple-storage");

var n;

var button = ToggleButton({
  id: "my-button",
  label: "my button",
  icon: {
    "16": "./icon-16.png",
    "32": "./icon-32.png",
    "64": "./icon-64.png"
  },
  onChange: handleChange
});

var panel = panels.Panel({
  contentURL: self.data.url("panel.html"),
  contentScriptFile: [self.data.url("jquery.js"),self.data.url("panel.js") ],
  onHide: handleHide
});

function handleChange(state) {
  if (state.checked) {
    panel.show({
      position: button
    });
  }
}

function handleHide() {
  button.state('window', {checked: false});
}

pageMod.PageMod({
  include: "*",
  contentScriptFile: [self.data.url("jquery.js"),self.data.url("content-script.js")],
  contentScriptWhen: "ready",
  attachTo: ['top','existing'],
  onAttach: function(worker) {
  
	worker.port.emit("my-addon-message","my-addon-message");
	worker.port.on("my-script-response",function(message){
		panel.port.emit("message",[message,ss.storage.amount]);
		ss.storage.amount=message;
	});
  }
});
panel.on("show", function() {
  panel.port.emit("show");
});